from tkinter import *
from PIL import ImageTk, Image
import random, time, os

class Menu:
    def __init__(self, master):

        self.image = Image.open("images/logo.png")
        self.image = self.image.resize((300, 300), Image.ANTIALIAS)
        self.logoimg = ImageTk.PhotoImage(self.image)

        self.master = master
        self.master.geometry("400x400")
        self.master.resizable(False, False)

        self.title = Label(self.master, text="Blackjack", width = 25, font = ("Courier", 24))
        self.start = Button(self.master, text = 'Start', width = 25, command = self.start, bg="green", font = ("Courier", 14))
        self.quit = Button(self.master, text = 'Quit', width = 25, command = self.kill, bg="red", font = ("Courier", 14))
        self.logo = Label(self.master, image=self.logoimg)

        self.title.pack()
        self.start.pack()
        self.quit.pack()
        self.logo.pack()

    def kill(self):
        self.master.destroy()
        sys.exit(0)

    def start(self):
        self.newWindow = Toplevel(self.master)
        self.app = Game(self.newWindow)

class Game:
    def __init__(self, master):
        
        self.master = master
        self.master.geometry("1000x700")
        self.master.resizable(False, False)

        self.createCards()
        self.dealCards()

        self.hitMe = Button(self.master, text= "Hit Me!", bg="yellow", width = 24, font = ("Courier", 14), command = lambda: self.hit)
        self.hitMe.grid(row=0,column=0)


    def createCards(self):
        self.cards = []
        for i in range(0,14):
            if i == 1:
                self.cards.append(["a","s"])
                self.cards.append(["a","c"])
                self.cards.append(["a","h"])
                self.cards.append(["a","d"])
            if i == 13:
                self.cards.append(["q","s"])
                self.cards.append(["q","c"])
                self.cards.append(["q","h"])
                self.cards.append(["q","d"])
            if i == 12:
                self.cards.append(["k","s"])
                self.cards.append(["k","c"])
                self.cards.append(["k","h"])
                self.cards.append(["k","d"])
            if i == 11:
                self.cards.append(["j","s"])
                self.cards.append(["j","c"])
                self.cards.append(["j","h"])
                self.cards.append(["j","d"])
            elif i > 1 and i < 11:
                self.cards.append([str(i), "s"])
                self.cards.append([str(i),"c"])
                self.cards.append([str(i),"h"])
                self.cards.append([str(i),"d"])
        random.shuffle(self.cards)


        print(f"{self.cards}")


    def dealCards(self):

        self.playerCards = []
        self.computerCards = []

        for i in range(0,2):

            self.playerCards.append( self.cards[i] )

            a = "".join(self.playerCards[i])
            print(a)

            self.imageUser = Image.open(f"images/{a}.png")
            self.imageUser = self.imageUser.resize((150, 180), Image.ANTIALIAS)
            self.cardimgUser = ImageTk.PhotoImage(self.imageUser)

            self.cardUser = Label(self.master, image=self.cardimgUser)
            self.cardUser.grid(row=3,column=i)

            del self.cards[i]
            
            self.computerCards.append( self.cards[i] )

            b = "".join(self.computerCards[i])
            print(b)
            
            self.imagePC = Image.open(f"images/{b}.png")
            self.imagePC = self.imagePC.resize((160, 180), Image.ANTIALIAS)
            self.cardimgPC = ImageTk.PhotoImage(self.imagePC)

            self.cardPC = Label(self.master, image=self.cardimgPC)
            self.cardPC.grid(row=2,column=i)
            

            
        print(f"{self.playerCards}\n{self.computerCards}\n{len(self.cards)}")           

        

    def hit(self):
        
        self.playerCards = playerCards
        self.playerCards.append(self.cards[0])
        del self.cards[0]
        
        print(self.playerCards, "\n")
        print(self.cards)
        



def main():
    root = Tk()
    app = Menu(root)
    root.mainloop()    
    

if __name__ == '__main__':
    main()


