from tkinter import *
from PIL import ImageTk, Image
import random, time, os

class Menu:
    def __init__(self, master):
        
        self.master = master
        self.menu()

    def menu(self):

        self.image = Image.open("images/logo.png")
        self.image = self.image.resize((300, 300), Image.ANTIALIAS)
        self.logoimg = ImageTk.PhotoImage(self.image)
        
        self.master.geometry("400x400")
        self.master.resizable(False, False)

        self.title = Label(self.master, text="Blackjack", width = 25, font = ("Courier", 24))
        self.start = Button(self.master, text = 'Start', width = 25, command = self.start, bg="green", font = ("Courier", 14))
        self.quit = Button(self.master, text = 'Quit', width = 25, command = self.kill, bg="red", font = ("Courier", 14))
        self.logo = Label(self.master, image=self.logoimg)

        self.title.pack()
        self.start.pack()
        self.quit.pack()
        self.logo.pack()

    def kill(self):
        self.master.destroy()
        sys.exit(0)

    def start(self):
        self.newWindow = Toplevel(self.master)
        self.app = Game(self.newWindow)

class Cards:
    def __init__(self, master):
        self.master = master
                
    # Find better way to create cards/ shorter code
    def createCards(self):
        self.cards = []
        for i in range(0,14):
            if i == 1:
                self.cards.append(["a","s"])
                self.cards.append(["a","c"])
                self.cards.append(["a","h"])
                self.cards.append(["a","d"])
            if i == 13:
                self.cards.append(["q","s"])
                self.cards.append(["q","c"])
                self.cards.append(["q","h"])
                self.cards.append(["q","d"])
            if i == 12:
                self.cards.append(["k","s"])
                self.cards.append(["k","c"])
                self.cards.append(["k","h"])
                self.cards.append(["k","d"])
            if i == 11:
                self.cards.append(["j","s"])
                self.cards.append(["j","c"])
                self.cards.append(["j","h"])
                self.cards.append(["j","d"])
            elif i > 1 and i < 11:
                self.cards.append([str(i), "s"])
                self.cards.append([str(i),"c"])
                self.cards.append([str(i),"h"])
                self.cards.append([str(i),"d"])
        random.shuffle(self.cards)
        return self.cards

    def dealCards(self):

        self.cardimages = []
        self.playerCards = []
        self.computerCards = []

        cards_to_remove = []
        for i in range(0,2):

            # Appends a card from a cards array I have made earlier and shuffled, each card looks like this ['5', 's']
            self.playerCards.append(self.cards[i])
            self.computerCards.append(self.cards[i+2])
            print(f"{self.playerCards}\n")

            a = "".join(self.playerCards[i])
            b = "".join(self.computerCards[i])
            
            # I have a collection of cards labbelled QD, AS... etc
            self.img = Image.open(f"images/{a}.png")
            self.img = self.img.resize((150, 170), Image.ANTIALIAS)
            self.cardUser = ImageTk.PhotoImage(self.img)

            self.img2 = Image.open(f"images/{b}.png")
            self.img2 = self.img2.resize((150, 170), Image.ANTIALIAS)
            self.cardComputer = ImageTk.PhotoImage(self.img2)

            self.img3 = Image.open(f"images/purple_back.png")
            self.img3 = self.img3.resize((150, 170), Image.ANTIALIAS)
            self.purpleBack = ImageTk.PhotoImage(self.img3)
       

            #We need persistant objects for images used in Label
            if self.cardUser not in self.cardimages:
                self.cardimages.append(self.cardUser)
            if self.cardComputer not in self.cardimages:
                self.cardimages.append(self.cardComputer)
            print(self.cardimages)

            self.cardUser = Label(self.master, image=self.cardUser)
            self.cardUser.grid(row=3,column=i)

            self.cardComputer = Label(self.master, image=self.cardComputer)
            self.cardComputer.grid(row=2,column=1)

            self.blankCard = Label(self.master, image=self.purpleBack)
            self.blankCard.grid(row=2,column=0)            

            cards_to_remove.append(self.cards[i])
            cards_to_remove.append(self.cards[i+2])
            print(f"CARDS TO REMOVE {cards_to_remove}")


        print(f"COMPUTER CARDS: {self.computerCards}")
        print(f"PLAYER CARDS: {self.playerCards}")
        print(f"\nCARDS BEFORE REMOVAL {self.cards}")
        for card in cards_to_remove:
            self.cards.remove(card)

        print(f"\nCARDS AFTER REMOVAL {self.cards}")

    def returnData(self):
        return self.playerCards, self.computerCards, self.cardimages


class Game:
    def __init__(self, master):

        self.cards = Cards.createCards(self)
        self.master = master
        self.mainWindow()        
    
    def mainWindow(self):
        
        self.master.geometry("1000x700")

        self.hitButton = Button(self.master, text= "Hit me!", width = 15, command = lambda : self.hit(), bg="lightblue", font = ("Courier", 14) )
        self.hitButton.grid(row=1,column=0)
        self.stickButton = Button(self.master, text= "Stick!", width = 15, command = self.stick(), bg="orange", font = ("Courier", 14) )
        self.stickButton.grid(row=1,column=1)

        Cards.dealCards(self)
        self.sumPlayer = self.sumCards()


    def sumCards(self):
        self.playerCards, self.computerCards, self.cardimages = Cards.returnData(self)
        x = 0
        for i in self.playerCards:
            print(i)
            if i[0] == "a":               
                x += 1
            if i[0] == "q":
                x += 10
            if i[0] == "k":
                x += 10
            if i[0] == "j":
                x += 10
            elif i[0] in ["1","2","3","4","5","6","7","8","9","10"]:
                x += int(i[0])

        self.sumPlayer = x

        self.labelSum = Label(self.master,text=f"Total: {self.sumPlayer}", width = 20, font = ("Courier", 14) )
        self.labelSum.grid(row=1,column=3)
        
        return self.sumPlayer

        
    def hit(self):
               
        print(f"\n\nPLAYER CARDS : {self.playerCards}\n\n")
        print(f" CARDS : {self.cards}\n\n")
        
        self.playerCards, self.computerCards, self.cardimages = Cards.returnData(self)
        self.playerCards.append(self.cards[0])
        a = "".join(self.cards[0])
        print(a)
        self.cards.remove(self.cards[0])
        self.sumPlayer = self.sumCards()
        print("\nTOTAL COUNT",self.sumPlayer)

        if self.sumPlayer > 21:
            self.bust()

        if len(self.cards) == 3:
            pass

        print(f"\n\n\n{self.cardimages}\n\n\n")

        self.img = Image.open(f"images/{a}.png")
        self.img = self.img.resize((150, 170), Image.ANTIALIAS)
        self.cardUser = ImageTk.PhotoImage(self.img)

        if self.cardUser not in self.cardimages:
            self.cardimages.append(self.cardUser)
        

        self.cardUser = Label(self.master, image=self.cardUser)
        self.cardUser.grid(row=3,column=len(self.playerCards))
        print(len(self.playerCards))

        print("AFTER\n\n")
        print(f"PLAYER CARDS : {self.playerCards}\n\n")
        print(f" CARDS : {self.cards}\n\n")
    def stick(self):
        pass
        # NOW COMPUTER PLAYS

    def bust(self):
        for i in self.cardimages:
            self.cardimages.remove(i)
        
        Cards.dealCards(self)
        self.sumCards()
                
def main():
    root = Tk()
    app = Menu(root)
    root.mainloop()    
    

if __name__ == '__main__':
    main()


