from tkinter import *
from PIL import ImageTk, Image
import random, time, os

class Menu:
    def __init__(self, master):

        self.image = Image.open("images/logo.png")
        self.image = self.image.resize((300, 300), Image.ANTIALIAS)
        self.logoimg = ImageTk.PhotoImage(self.image)

        self.master = master
        self.master.geometry("400x400")
        self.master.resizable(False, False)

        self.title = Label(self.master, text="Blackjack", width = 25, font = ("Courier", 24))
        self.start = Button(self.master, text = 'Start', width = 25, command = self.start, bg="green", font = ("Courier", 14))
        self.quit = Button(self.master, text = 'Quit', width = 25, command = self.kill, bg="red", font = ("Courier", 14))
        self.logo = Label(self.master, image=self.logoimg)

        self.title.pack()
        self.start.pack()
        self.quit.pack()
        self.logo.pack()

    def kill(self):
        self.master.destroy()
        sys.exit(0)

    def start(self):
        self.newWindow = Toplevel(self.master)
        self.app = Game(self.newWindow)

class Game:
    def __init__(self, master):
        
        self.master = master
        self.master.geometry("1000x700")
        self.master.resizable(False, False)

        self.createCards()
        self.dealCards()

        self.hitMe = Button(self.master, text= "Hit Me!", bg="yellow", width = 15, font = ("Courier", 14), command = self.hit)
        self.hitMe.grid(row=0,column=0)


    def createCards(self):
        self.cards = []
        for i in range(0,14):
            if i == 1:
                self.cards.append(["a","s"])
                self.cards.append(["a","c"])
                self.cards.append(["a","h"])
                self.cards.append(["a","d"])
            if i == 13:
                self.cards.append(["q","s"])
                self.cards.append(["q","c"])
                self.cards.append(["q","h"])
                self.cards.append(["q","d"])
            if i == 12:
                self.cards.append(["k","s"])
                self.cards.append(["k","c"])
                self.cards.append(["k","h"])
                self.cards.append(["k","d"])
            if i == 11:
                self.cards.append(["j","s"])
                self.cards.append(["j","c"])
                self.cards.append(["j","h"])
                self.cards.append(["j","d"])
            elif i > 1 and i < 11:
                self.cards.append([str(i), "s"])
                self.cards.append([str(i),"c"])
                self.cards.append([str(i),"h"])
                self.cards.append([str(i),"d"])
        random.shuffle(self.cards)


        print(f"{self.cards}")


    def dealCards(self):

        self.playerCards = []
        self.computerCards = []

        for i in range(0,2):

            self.playerCards.append(self.cards[i])
            del self.cards[i]            
            self.computerCards.append(self.cards[i])

        print(f"{self.playerCards}\n{self.computerCards}\n{len(self.cards)}")   
        

        a = "".join(self.playerCards[0])
        print(a)

        self.imageUser1 = Image.open(f"images/{a}.png")
        self.imageUser1 = self.imageUser1.resize((130, 170), Image.ANTIALIAS)
        self.cardimgUser1 = ImageTk.PhotoImage(self.imageUser1)

        self.cardUser1 = Label(self.master, image=self.cardimgUser1)
        self.cardUser1.grid(row=3,column=1)

    
        b = "".join(self.playerCards[1])
        print(b)

        self.imageUser2 = Image.open(f"images/{b}.png")
        self.imageUser2 = self.imageUser2.resize((130, 170), Image.ANTIALIAS)
        self.cardimgUser2 = ImageTk.PhotoImage(self.imageUser2)

        self.cardUser2 = Label(self.master, image=self.cardimgUser2)
        self.cardUser2.grid(row=3,column=2)

        c = "".join(self.computerCards[0])
        print(c)
        
        self.imagePC1 = Image.open(f"images/{c}.png")
        self.imagePC1 = self.imagePC1.resize((130, 170), Image.ANTIALIAS)
        self.cardimagePC1 = ImageTk.PhotoImage(self.imagePC1)

        self.cardPC1 = Label(self.master, image=self.cardimagePC1)
        self.cardPC1.grid(row=2,column=1)

        self.imagePC2 = Image.open(f"images/purple_back.png")
        self.imagePC2 = self.imagePC2.resize((130, 170), Image.ANTIALIAS)
        self.cardimagePC2 = ImageTk.PhotoImage(self.imagePC2)

        self.cardPC2 = Label(self.master, image=self.cardimagePC2)
        self.cardPC2.grid(row=2,column=2)
                

        

    def hit(self):
        
        self.playerCards.append(self.cards[0])
        h = "".join(self.cards[0])
        print(self.playerCards)
        del self.cards[0]

        sumCards = 0
        for i in self.playerCards:
            if i[0] == "a":
                i[0] = 1
            if i[0] == "q":
                i[0] = 10
            if i[0] == "k":
                i[0] = 10
            if i[0] == "j":
                i[0] = 10
                
            sumCards += int(i[0])

        print(sumCards)
        

        



def main():
    root = Tk()
    app = Menu(root)
    root.mainloop()    
    

if __name__ == '__main__':
    main()


